/* GdkPixbuf RGBA C-Source image dump 1-byte-run-length-encoded */

#ifdef __SUNPRO_C
#pragma align 4 (stock_sylpheed_newmail_16)
#endif
#ifdef __GNUC__
static const guint8 stock_sylpheed_newmail_16[] __attribute__ ((__aligned__ (4))) = 
#else
static const guint8 stock_sylpheed_newmail_16[] = 
#endif
{ ""
  /* Pixbuf magic (0x47646b50) */
  "GdkP"
  /* length: header (24) + pixel_data (165) */
  "\0\0\0\275"
  /* pixdata_type (0x2010002) */
  "\2\1\0\2"
  /* rowstride (64) */
  "\0\0\0@"
  /* width (16) */
  "\0\0\0\20"
  /* height (16) */
  "\0\0\0\20"
  /* pixel_data: */
  "\262\0\0\0\0\215U\257f\377\202\0\0\0\0\216U\257f\377\202\0\0\0\0\202"
  "U\257f\377\202\0\0\0\0\207U\257f\377\1\0\0\0\0\202U\257f\377\202\0\0"
  "\0\0\204U\257f\377\1\0\0\0\0\204U\257f\377\202\0\0\0\0\203U\257f\377"
  "\202\0\0\0\0\205U\257f\377\204\0\0\0\0\205U\257f\377\202\0\0\0\0\216"
  "U\257f\377\202\0\0\0\0\216U\257f\377\202\0\0\0\0\216U\257f\377\202\0"
  "\0\0\0\216U\257f\377\202\0\0\0\0\216U\257f\377\203\0\0\0\0\214U\257f"
  "\377\242\0\0\0\0"};


