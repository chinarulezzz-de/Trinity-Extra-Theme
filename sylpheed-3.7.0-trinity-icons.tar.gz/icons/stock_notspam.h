/* GdkPixbuf RGBA C-Source image dump 1-byte-run-length-encoded */

#ifdef __SUNPRO_C
#pragma align 4 (stock_notspam)
#endif
#ifdef __GNUC__
static const guint8 stock_notspam[] __attribute__ ((__aligned__ (4))) = 
#else
static const guint8 stock_notspam[] = 
#endif
{ ""
  /* Pixbuf magic (0x47646b50) */
  "GdkP"
  /* length: header (24) + pixel_data (390) */
  "\0\0\1\236"
  /* pixdata_type (0x2010002) */
  "\2\1\0\2"
  /* rowstride (64) */
  "\0\0\0@"
  /* width (16) */
  "\0\0\0\20"
  /* height (16) */
  "\0\0\0\20"
  /* pixel_data: */
  "\252\0\0\0\0\206U\257f\0\211\0\0\0\0\203U\257f\0\2U\257f\37U\257f-\202"
  "U\257f\0\210\0\0\0\0\203U\257f\0\5U\257f\"U\257f\275U\257f\305U\257f"
  "\24U\257f\0\207\0\0\0\0\203U\257f\0\7U\257f!U\257f\274U\257f\364U\257"
  "fiU\257f\3U\257f\0\0\0\0\0\210U\257f\0\4U\257f!U\257f\274U\257f\364U"
  "\257fh\205U\257f\0\2U\257f\6U\257f\22\204U\257f\0\4U\257f!U\257f\274"
  "U\257f\364U\257fh\203U\257f\0\1\0\0\0\0\202U\257f\0\3U\257flU\257f\273"
  "U\257f*\202U\257f\0\4U\257f!U\257f\274U\257f\364U\257fh\203U\257f\0\202"
  "\0\0\0\0\202U\257f\0\10U\257fWU\257f\355U\257f\307U\257f(U\257f\40U\257"
  "f\274U\257f\364U\257fh\203U\257f\0\203\0\0\0\0\203U\257f\0\6U\257fYU"
  "\257f\354U\257f\314U\257f\305U\257f\364U\257fh\203U\257f\0\205\0\0\0"
  "\0\203U\257f\0\4U\257fYU\257f\355U\257f\366U\257fg\203U\257f\0\207\0"
  "\0\0\0\203U\257f\0\3U\257fUU\257f`U\257f\1\202U\257f\0\211\0\0\0\0\206"
  "U\257f\0\213\0\0\0\0\204U\257f\0\230\0\0\0\0"};


