/* GdkPixbuf RGBA C-Source image dump 1-byte-run-length-encoded */

#ifdef __SUNPRO_C
#pragma align 4 (stock_insert_file)
#endif
#ifdef __GNUC__
static const guint8 stock_insert_file[] __attribute__ ((__aligned__ (4))) = 
#else
static const guint8 stock_insert_file[] = 
#endif
{ ""
  /* Pixbuf magic (0x47646b50) */
  "GdkP"
  /* length: header (24) + pixel_data (581) */
  "\0\0\2]"
  /* pixdata_type (0x2010002) */
  "\2\1\0\2"
  /* rowstride (64) */
  "\0\0\0@"
  /* width (16) */
  "\0\0\0\20"
  /* height (16) */
  "\0\0\0\20"
  /* pixel_data: */
  "\221U\257f\0\2U\257f\10U\257f\33\213U\257f\34\5U\257f\20U\257f\0U\257"
  "f\31U\257f\240U\257f\342\213U\257f\344\6U\257f\304U\257fEU\257fZU\257"
  "f\373U\257f\306U\257f\243\211U\257f\244\6U\257f\257U\257f\372U\257f\256"
  "U\257ffU\257f\376U\257fY\212U\257f\0\7U\257f\35U\257f\345U\257f\276U"
  "\257feU\257f\376U\257fZU\257f\0\202\0\0\0\0\3U\257f\1U\257fLU\257f\25"
  "\202U\257f\0\11\0\0\0\0U\257f\0U\257f\35U\257f\345U\257f\275U\257f#U"
  "\257fYU\257f\37U\257f\0\202\0\1\1\0\1U\257f\0\202U\257f\246\1U\257f\21"
  "\203U\257f\0\6U\257f\35U\257f\345U\257f\275U\257f@U\257f\241U\257f\246"
  "\204U\257f\247\4U\257f\341U\257f\377U\257f\242U\257f\22\202U\257f\0\6"
  "U\257f\35U\257f\345U\257f\275U\257f[U\257f\343U\257f\346\204U\257f\347"
  "\4U\257f\367U\257f\377U\257f\320U\257f#\202U\257f\0\7U\257f\35U\257f"
  "\345U\257f\275U\257f\27U\257f:U\257f'U\257f\34\203U\257f\35\3U\257f\263"
  "U\257f\327U\257f4\203U\257f\0\6U\257f\35U\257f\345U\257f\275U\257fYU"
  "\257f\336U\257fM\204U\257f\0\2U\257fvU\257f9\204U\257f\0\6U\257f\35U"
  "\257f\345U\257f\275U\257ffU\257f\377U\257fW\204U\257f\0\1U\257f\4\205"
  "U\257f\0\7U\257f\31U\257f\345U\257f\275U\257fcU\257f\376U\257f\221U\257"
  "fR\203U\257fU\1U\257fT\204U\257fU\7U\257fTU\257fiU\257f\360U\257f\272"
  "U\257f1U\257f\324U\257f\375\212U\257f\374\6U\257f\375U\257f\360U\257"
  "fqU\257f\0U\257f)U\257fU\213U\257fW\2U\257f=U\257f\10\220U\257f\0"};


