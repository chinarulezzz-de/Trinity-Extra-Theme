/* GdkPixbuf RGBA C-Source image dump 1-byte-run-length-encoded */

#ifdef __SUNPRO_C
#pragma align 4 (stock_mail_compose_16)
#endif
#ifdef __GNUC__
static const guint8 stock_mail_compose_16[] __attribute__ ((__aligned__ (4))) = 
#else
static const guint8 stock_mail_compose_16[] = 
#endif
{ ""
  /* Pixbuf magic (0x47646b50) */
  "GdkP"
  /* length: header (24) + pixel_data (467) */
  "\0\0\1\353"
  /* pixdata_type (0x2010002) */
  "\2\1\0\2"
  /* rowstride (64) */
  "\0\0\0@"
  /* width (16) */
  "\0\0\0\20"
  /* height (16) */
  "\0\0\0\20"
  /* pixel_data: */
  "\220\0\0\0\0\221U\257f\0\2U\257f\7U\257f@\212U\257fZ\2U\257fPU\257f\26"
  "\202U\257f\0\2U\257faU\257f\362\212U\257f\377\10U\257f\376U\257f\242"
  "U\257f\12U\257f\0U\257f\241U\257f\364U\257f\272U\257f\367\207U\257f\377"
  "\12U\257f\312U\257f\330U\257f\342U\257f\40U\257f\0U\257f\243U\257f\363"
  "U\257f^U\257fbU\257f\322\204U\257f\377\30U\257f\354U\257f\207U\257fE"
  "U\257f\310U\257f\344U\257f!U\257f\0U\257f\242U\257f\377U\257f\356U\257"
  "f\217U\257fEU\257f\216U\257f\357U\257f\375U\257f\266U\257fOU\257fiU\257"
  "f\327U\257f\377U\257f\340U\257f!U\257f\0U\257f\242\203U\257f\377\7U\257"
  "f\322U\257fbU\257fTU\257fgU\257fKU\257f\257U\257f\373\202U\257f\377\4"
  "U\257f\340U\257f!U\257f\0U\257f\243\204U\257f\377\4U\257f\370U\257f\245"
  "U\257f\207U\257f\346\204U\257f\377\4U\257f\340U\257f!U\257f\0U\257f\243"
  "\214U\257f\377\4U\257f\340U\257f!U\257f\0U\257f\244\214U\257f\377\4U"
  "\257f\340U\257f!U\257f\0U\257f\245\214U\257f\377\4U\257f\341U\257f!U"
  "\257f\0U\257f\203\214U\257f\377\6U\257f\305U\257f\23U\257f\0U\257f\34"
  "U\257f\204U\257f\246\210U\257f\245\3U\257f\246U\257f\232U\257f=\205U"
  "\257f\0\210\0\0\0\0\204U\257f\0\220\0\0\0\0"};


