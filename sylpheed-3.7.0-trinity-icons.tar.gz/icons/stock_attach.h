/* GdkPixbuf RGBA C-Source image dump 1-byte-run-length-encoded */

#ifdef __SUNPRO_C
#pragma align 4 (stock_attach)
#endif
#ifdef __GNUC__
static const guint8 stock_attach[] __attribute__ ((__aligned__ (4))) = 
#else
static const guint8 stock_attach[] = 
#endif
{ ""
  /* Pixbuf magic (0x47646b50) */
  "GdkP"
  /* length: header (24) + pixel_data (135) */
  "\0\0\0\237"
  /* pixdata_type (0x2010002) */
  "\2\1\0\2"
  /* rowstride (64) */
  "\0\0\0@"
  /* width (16) */
  "\0\0\0\20"
  /* height (16) */
  "\0\0\0\20"
  /* pixel_data: */
  "\323\0\0\0\0\213U\257f\377\204\0\0\0\0\202U\257f\377\211\0\0\0\0\202"
  "U\257f\377\203\0\0\0\0\1U\257f\377\202\0\0\0\0\207U\257f\377\202\0\0"
  "\0\0\1U\257f\377\202\0\0\0\0\202U\257f\377\202\0\0\0\0\1U\257f\377\207"
  "\0\0\0\0\202U\257f\377\203\0\0\0\0\1U\257f\377\202\0\0\0\0\211U\257f"
  "\377\204\0\0\0\0\202U\257f\377\217\0\0\0\0\211U\257f\377\304\0\0\0\0"};


