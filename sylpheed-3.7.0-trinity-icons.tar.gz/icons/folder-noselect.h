/* GdkPixbuf RGBA C-Source image dump 1-byte-run-length-encoded */

#ifdef __SUNPRO_C
#pragma align 4 (folder_noselect)
#endif
#ifdef __GNUC__
static const guint8 folder_noselect[] __attribute__ ((__aligned__ (4))) = 
#else
static const guint8 folder_noselect[] = 
#endif
{ ""
  /* Pixbuf magic (0x47646b50) */
  "GdkP"
  /* length: header (24) + pixel_data (368) */
  "\0\0\1\210"
  /* pixdata_type (0x2010002) */
  "\2\1\0\2"
  /* rowstride (64) */
  "\0\0\0@"
  /* width (16) */
  "\0\0\0\20"
  /* height (16) */
  "\0\0\0\20"
  /* pixel_data: */
  "\220\0\0\0\0\211U\257f\0\207\0\0\0\0\3U\257f\0U\257f\7U\257f@\203U\257"
  "fZ\2U\257fSU\257f\22\211U\257f\0\2U\257faU\257f\362\203U\257f\377\4U"
  "\257f\376U\257f\241U\257f%U\257f\34\203U\257f\35\2U\257f\30U\257f\2\202"
  "U\257f\0\1U\257f\240\205U\257f\377\2U\257f\376U\257f\346\203U\257f\342"
  "\6U\257f\343U\257f\332U\257fqU\257f\3U\257f\0U\257f\242\214U\257f\377"
  "\4U\257f\330U\257f\33U\257f\0U\257f\242\214U\257f\377\4U\257f\341U\257"
  "f!U\257f\0U\257f\242\214U\257f\377\4U\257f\340U\257f!U\257f\0U\257f\243"
  "\214U\257f\377\4U\257f\340U\257f!U\257f\0U\257f\243\214U\257f\377\4U"
  "\257f\340U\257f!U\257f\0U\257f\244\214U\257f\377\4U\257f\340U\257f!U"
  "\257f\0U\257f\245\214U\257f\377\4U\257f\341U\257f!U\257f\0U\257f\203"
  "\214U\257f\377\6U\257f\305U\257f\23U\257f\0U\257f\34U\257f\204U\257f"
  "\246\210U\257f\245\3U\257f\246U\257f\232U\257f=\205U\257f\0\210\0\0\0"
  "\0\204U\257f\0\220\0\0\0\0"};


